Os updates:
-O castelo no final da fase 1 que apresentava tiles de colisão
(que eram para serem normais) foram corrigidos;
-Foi adicionado uma sprite para entrada no castelo da fase 1, feita por
Stikone que no entanto, não exigia créditos se os fins do jogo não 
fossem comerciais;
-Foi feita a programação completa da transação do personagem da fase 
1 para 2(final);
-Boss adicionado à segunda fase.