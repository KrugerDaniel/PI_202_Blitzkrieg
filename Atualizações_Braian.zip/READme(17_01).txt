As atualizações/correções de hoje foram:

- A câmera que segue o personagem principal foi corrigida através de 
um bloco de códigos que faz com que a câmera se adapte em qualquer 
mapa, poisa ele reconhece todo o espaço utilizado no mapa para definir
seus limites;

- Paredes invisíveis foram adicionadas para impedir que o usuário caia
infinitamente do mapa se o mesmo atravessar a borda;

- Os espinhos contidos na Fase 1 do jogo foram posicionados e as 
devidas funções que fazem com que o mesmo cause um dano ao usuário 
quando entram em contato.