Músicas e efeitos sonoros adicionados ao jogo, especificamente:

-Música da fase 1: The Trooper - Iron Maiden v. 8 bits;

-Música da fase 2(final): Death in fire - Amon Amarth v. 8 bits;

-Efeito sonoro de pulo, tiro e seleção das opções do menu.