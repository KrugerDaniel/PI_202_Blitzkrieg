O update consiste na construção(modelagem) da segunda e final fase do 
jogo utilizando sprites disponibilizadas por "simon13666". Além da 
parte visual, o personagem principal já foi adicionado junto ao seu GUI.
